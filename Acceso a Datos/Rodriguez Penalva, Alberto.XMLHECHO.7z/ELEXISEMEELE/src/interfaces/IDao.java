package interfaces;

import org.w3c.dom.NodeList;

public interface IDao {
    public String traducir();
    public void insertar(NodeList lista);
}

package com.example.retrofitservlet;

public class LoginPresenter {
    //private LoginView view;
    private ApiService apiService;

   /* public LoginPresenter(LoginView view, ApiService apiService) {
        this.view = view;
        this.apiService = apiService;
    }
*/
    public void login(String username, String password) {
        // Realiza la llamada a la API con Retrofit
        // Procesa la respuesta y actualiza la vista
    }
}


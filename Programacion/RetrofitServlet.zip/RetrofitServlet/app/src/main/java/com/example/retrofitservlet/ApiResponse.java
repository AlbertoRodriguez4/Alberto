package com.example.retrofitservlet;
public class ApiResponse {
    // SerializedName("mensaje")
    private boolean success;
    private String message;
    private User user;

    // Getters y setters
}

<?php
    echo 'Hola desde usuarios';
?>
<br>
<button type="button" onclick="buscarUsuarios()">Buscar</button>
<div id="capaResultadoBusqueda">
    
</div>
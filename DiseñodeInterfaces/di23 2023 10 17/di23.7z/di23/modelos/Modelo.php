<?php
class Modelo {
    function __construct()
    {
        //Constructor de la clase modelo
    }
}
?>